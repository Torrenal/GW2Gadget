package cooking.apiInterface.json;

public interface JSONPoint
{
}
